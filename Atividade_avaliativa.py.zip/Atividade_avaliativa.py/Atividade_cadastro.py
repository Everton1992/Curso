from Pessoa import Pessoa
 
lista_de_clientes = []
 
def cadastrar_novo_cliente(lista):
    print('\n *** Cadastrar novo cliente ***')
    print('================================')
 
    nome_cliente = input('Digite o nome do CLIENTE: ')
    cpf_cliente = input(f'Digite o CPF de {nome_cliente}: ') 
 
    while True:
        try:
            idade_cliente = int(input(f'Digite a IDADE de {nome_cliente}: '))
            if idade_cliente > 0:
                break
            else:
                print('Por favor, digite uma idade válida (maior que zero)!')
        except ValueError:
            print('Entrada inválida, por favor digite um número para a idade!')
 
    telefone_cliente = input(f'Digite o TELEFONE de {nome_cliente}: ')
    endereco_cliente = input(f'Digite o ENDEREÇO de {nome_cliente}: ')
    e_mail_cliente = input(f'Digite o E-MAIL de {nome_cliente}: ')
 
    novo_cliente = Pessoa(nome_cliente, cpf_cliente, idade_cliente, telefone_cliente, endereco_cliente, e_mail_cliente)
 
    lista_de_clientes.append(novo_cliente)
    print(f'\nCliente: {novo_cliente.nome} cadastrado com sucesso!')
 
def mostrar_clientes(lista):
    print('\n--- Lista de todos os clientes ---')
    print('==================================\n')
    if not lista_de_clientes:
        print('Nenhum cliente foi cadastrado!')
    else:
        for i, cliente_cadastrado in enumerate(lista_de_clientes):
            print(f'\n*** Cliente {i+1} ***')
            print('=================')
            cliente_cadastrado.mostrar()
 
def buscar_cliente(lista):
    print('\n*** Buscar Cliente ***')
    termo_busca = input('Digite o CPF do cliente para buscar: ').strip()
 
    clientes_encontrados = []
    for cliente in lista:
        if cliente.cpf == termo_busca:
            clientes_encontrados.append(cliente)
 
    if clientes_encontrados:
        print(f'\n{len(clientes_encontrados)} cliente(s) encontrado(s): ')
        for i, cliente_encontrado in enumerate(clientes_encontrados):
            print(f'\n*** Cliente Encontrado {i+1} ***')
            print('============================')
            cliente_encontrado.mostrar()
    else:
        print(f'Nenhum cliente encontrado com o CPF "{termo_busca}".')
 
while True:
    print('\n*** Menu de Cadastro ***')
    print('========================\n')
    print('1. Cadastrar novo cliente: ')
    print('2. Lista de clientes: ')
    print('3. Buscar cliente: ') 
    print('4. Sair: ') 
 
    opcao = input('Escolha uma opção: ')
 
    if opcao == '1':
        cadastrar_novo_cliente(lista_de_clientes)
    
    elif opcao == '2':
        mostrar_clientes(lista_de_clientes)
 
    elif opcao == '3': 
        buscar_cliente(lista_de_clientes)
 
    elif opcao == '4': 
        print('Menu encerrado.')
        break
    else:
        print('Opção inválida, tente novamente!')
 
print('\nEncerrando o sistema!')